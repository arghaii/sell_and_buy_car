import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extended with profile fields for car marketplace.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Car listings table
 */
export const carListings = mysqlTable("carListings", {
  id: int("id").autoincrement().primaryKey(),
  sellerId: int("sellerId").notNull(),
  make: varchar("make", { length: 100 }).notNull(),
  model: varchar("model", { length: 100 }).notNull(),
  year: int("year").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  mileage: int("mileage").notNull(),
  condition: mysqlEnum("condition", ["excellent", "good", "fair", "poor"]).notNull(),
  description: text("description"),
  color: varchar("color", { length: 50 }),
  transmission: varchar("transmission", { length: 50 }),
  fuelType: varchar("fuelType", { length: 50 }),
  bodyType: varchar("bodyType", { length: 50 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CarListing = typeof carListings.$inferSelect;
export type InsertCarListing = typeof carListings.$inferInsert;

/**
 * Car images table - stores S3 URLs and metadata
 */
export const carImages = mysqlTable("carImages", {
  id: int("id").autoincrement().primaryKey(),
  carId: int("carId").notNull(),
  imageUrl: text("imageUrl").notNull(),
  imageKey: varchar("imageKey", { length: 255 }).notNull(),
  isPrimary: boolean("isPrimary").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CarImage = typeof carImages.$inferSelect;
export type InsertCarImage = typeof carImages.$inferInsert;

/**
 * Buyer inquiries table - tracks buyer interest in listings
 */
export const buyerInquiries = mysqlTable("buyerInquiries", {
  id: int("id").autoincrement().primaryKey(),
  carId: int("carId").notNull(),
  buyerId: int("buyerId").notNull(),
  message: text("message"),
  status: mysqlEnum("status", ["pending", "contacted", "interested", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BuyerInquiry = typeof buyerInquiries.$inferSelect;
export type InsertBuyerInquiry = typeof buyerInquiries.$inferInsert;

/**
 * Payments table - tracks Stripe transactions
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  inquiryId: int("inquiryId").notNull(),
  buyerId: int("buyerId").notNull(),
  carId: int("carId").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }).notNull().unique(),
  status: mysqlEnum("status", ["pending", "succeeded", "failed", "cancelled"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

/**
 * Notifications table - tracks seller notifications
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["buyer_inquiry", "payment_received", "listing_update"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content"),
  relatedCarId: int("relatedCarId"),
  relatedInquiryId: int("relatedInquiryId"),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Relations
 */
export const usersRelations = relations(users, ({ many }) => ({
  carListings: many(carListings),
  buyerInquiries: many(buyerInquiries),
  payments: many(payments),
  notifications: many(notifications),
}));

export const carListingsRelations = relations(carListings, ({ one, many }) => ({
  seller: one(users, {
    fields: [carListings.sellerId],
    references: [users.id],
  }),
  images: many(carImages),
  inquiries: many(buyerInquiries),
  payments: many(payments),
}));

export const carImagesRelations = relations(carImages, ({ one }) => ({
  car: one(carListings, {
    fields: [carImages.carId],
    references: [carListings.id],
  }),
}));

export const buyerInquiriesRelations = relations(buyerInquiries, ({ one }) => ({
  car: one(carListings, {
    fields: [buyerInquiries.carId],
    references: [carListings.id],
  }),
  buyer: one(users, {
    fields: [buyerInquiries.buyerId],
    references: [users.id],
  }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  inquiry: one(buyerInquiries, {
    fields: [payments.inquiryId],
    references: [buyerInquiries.id],
  }),
  buyer: one(users, {
    fields: [payments.buyerId],
    references: [users.id],
  }),
  car: one(carListings, {
    fields: [payments.carId],
    references: [carListings.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
  car: one(carListings, {
    fields: [notifications.relatedCarId],
    references: [carListings.id],
  }),
}));
