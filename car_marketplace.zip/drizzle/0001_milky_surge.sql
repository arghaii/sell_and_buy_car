CREATE TABLE `buyerInquiries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`carId` int NOT NULL,
	`buyerId` int NOT NULL,
	`message` text,
	`status` enum('pending','contacted','interested','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `buyerInquiries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `carImages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`carId` int NOT NULL,
	`imageUrl` text NOT NULL,
	`imageKey` varchar(255) NOT NULL,
	`isPrimary` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `carImages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `carListings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sellerId` int NOT NULL,
	`make` varchar(100) NOT NULL,
	`model` varchar(100) NOT NULL,
	`year` int NOT NULL,
	`price` decimal(10,2) NOT NULL,
	`mileage` int NOT NULL,
	`condition` enum('excellent','good','fair','poor') NOT NULL,
	`description` text,
	`color` varchar(50),
	`transmission` varchar(50),
	`fuelType` varchar(50),
	`bodyType` varchar(50),
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `carListings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('buyer_inquiry','payment_received','listing_update') NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text,
	`relatedCarId` int,
	`relatedInquiryId` int,
	`isRead` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`inquiryId` int NOT NULL,
	`buyerId` int NOT NULL,
	`carId` int NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`currency` varchar(3) NOT NULL DEFAULT 'USD',
	`stripePaymentIntentId` varchar(255) NOT NULL,
	`status` enum('pending','succeeded','failed','cancelled') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`),
	CONSTRAINT `payments_stripePaymentIntentId_unique` UNIQUE(`stripePaymentIntentId`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);