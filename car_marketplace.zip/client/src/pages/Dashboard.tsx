import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2, ChevronLeft, Bell } from "lucide-react";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();

  const { data: notifications, isLoading } = trpc.notifications.getAll.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const markAsRead = trpc.notifications.markAsRead.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-foreground/60 mb-4">Please sign in to view your dashboard</p>
          <Button onClick={() => navigate("/")}>Go Home</Button>
        </div>
      </div>
    );
  }

  const handleMarkAsRead = async (notificationId: number) => {
    try {
      await markAsRead.mutateAsync(notificationId);
    } catch (error) {
      console.error("Failed to mark as read");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="container py-6">
          <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="mb-4">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <h1>Dashboard</h1>
        </div>
      </div>

      <div className="container py-12">
        <div className="grid grid-cols-3 gap-8">
          {/* Sidebar */}
          <div className="border-r border-border pr-8">
            <h3 className="font-bold mb-6">Menu</h3>
            <div className="space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => navigate("/my-listings")}
              >
                My Listings
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => navigate("/create-listing")}
              >
                Create Listing
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
              >
                My Inquiries
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
              >
                Saved Cars
              </Button>
            </div>
          </div>

          {/* Main Content */}
          <div className="col-span-2">
            <h2 className="mb-8">Notifications</h2>

            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : !notifications || notifications.length === 0 ? (
              <div className="text-center py-12">
                <Bell className="w-12 h-12 text-foreground/20 mx-auto mb-4" />
                <p className="text-foreground/60">No notifications yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`border p-6 cursor-pointer transition-colors ${
                      notification.isRead
                        ? "border-border bg-background"
                        : "border-primary bg-primary/5"
                    }`}
                    onClick={() => !notification.isRead && handleMarkAsRead(notification.id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-bold mb-2">{notification.title}</h3>
                        {notification.content && (
                          <p className="text-sm text-foreground/70 mb-2">
                            {notification.content}
                          </p>
                        )}
                        <p className="text-xs text-foreground/50">
                          {new Date(notification.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      {!notification.isRead && (
                        <div className="w-3 h-3 bg-primary rounded-full ml-4 mt-1" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
