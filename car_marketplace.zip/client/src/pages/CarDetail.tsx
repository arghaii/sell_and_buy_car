import { useParams, useLocation } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2, ChevronLeft, Mail, Phone } from "lucide-react";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";

export default function CarDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [inquiryMessage, setInquiryMessage] = useState("");
  const [showInquiryForm, setShowInquiryForm] = useState(false);

  const carId = parseInt(id || "0");
  const { data: car, isLoading } = trpc.cars.getById.useQuery(carId);
  const { data: images } = trpc.images.getByCarId.useQuery(carId);
  const createInquiry = trpc.inquiries.create.useMutation();

  const handleInquiry = async () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    try {
      await createInquiry.mutateAsync({
        carId,
        message: inquiryMessage,
      });
      toast.success("Inquiry sent successfully!");
      setInquiryMessage("");
      setShowInquiryForm(false);
    } catch (error) {
      toast.error("Failed to send inquiry");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!car) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <Button variant="ghost" onClick={() => navigate("/browse")} className="mb-4">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <p className="text-foreground/60">Car not found</p>
        </div>
      </div>
    );
  }

  const primaryImage = images?.find(img => img.isPrimary) || images?.[0];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="container py-6">
          <Button variant="ghost" size="sm" onClick={() => navigate("/browse")} className="mb-4">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back to Browse
          </Button>
        </div>
      </div>

      <div className="container py-12">
        <div className="grid grid-cols-3 gap-12">
          {/* Images */}
          <div className="col-span-2">
            <div className="aspect-video bg-secondary mb-6" />
            {images && images.length > 1 && (
              <div className="grid grid-cols-4 gap-4">
                {images.map((img) => (
                  <div key={img.id} className="aspect-square bg-secondary cursor-pointer hover:opacity-80" />
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div>
            <h1 className="mb-2">
              {car.year} {car.make} {car.model}
            </h1>
            <p className="text-foreground/60 mb-8">
              {car.mileage.toLocaleString()} miles • {car.condition}
            </p>

            {/* Price */}
            <div className="border-t border-b border-border py-6 mb-8">
              <p className="text-sm text-foreground/60 mb-2">Price</p>
              <p className="text-4xl font-bold text-primary">
                ${car.price.toLocaleString()}
              </p>
            </div>

            {/* Specs */}
            <div className="space-y-4 mb-8">
              <div>
                <p className="text-sm text-foreground/60">Transmission</p>
                <p className="font-semibold">{car.transmission || "Not specified"}</p>
              </div>
              <div>
                <p className="text-sm text-foreground/60">Fuel Type</p>
                <p className="font-semibold">{car.fuelType || "Not specified"}</p>
              </div>
              <div>
                <p className="text-sm text-foreground/60">Body Type</p>
                <p className="font-semibold">{car.bodyType || "Not specified"}</p>
              </div>
              <div>
                <p className="text-sm text-foreground/60">Color</p>
                <p className="font-semibold">{car.color || "Not specified"}</p>
              </div>
            </div>

            {/* Inquiry Button */}
            {user?.id !== car.sellerId && (
              <>
                {!showInquiryForm ? (
                  <Button
                    className="w-full mb-4"
                    onClick={() => setShowInquiryForm(true)}
                  >
                    Express Interest
                  </Button>
                ) : (
                  <div className="border border-border p-6 mb-4">
                    <h3 className="font-bold mb-4">Send Inquiry</h3>
                    <Textarea
                      placeholder="Tell the seller why you're interested..."
                      value={inquiryMessage}
                      onChange={(e) => setInquiryMessage(e.target.value)}
                      className="mb-4"
                    />
                    <div className="flex gap-2">
                      <Button
                        className="flex-1"
                        onClick={handleInquiry}
                        disabled={createInquiry.isPending}
                      >
                        {createInquiry.isPending ? "Sending..." : "Send"}
                      </Button>
                      <Button
                        variant="outline"
                        className="flex-1"
                        onClick={() => setShowInquiryForm(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {/* Description */}
        {car.description && (
          <div className="border-t border-border mt-12 pt-12">
            <h2 className="mb-6">About This Car</h2>
            <p className="text-foreground/70 leading-relaxed max-w-2xl">
              {car.description}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
