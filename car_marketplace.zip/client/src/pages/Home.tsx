import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Loader2, Search, Plus, ChevronRight } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useTranslation } from 'react-i18next';
import LanguageSwitcher from "@/components/LanguageSwitcher";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const { t } = useTranslation();
  const [searchMake, setSearchMake] = useState("");
  const [searchModel, setSearchModel] = useState("");
  const [searchMaxPrice, setSearchMaxPrice] = useState<number | undefined>();

  // Get featured listings
  const { data: featuredListings, isLoading } = trpc.cars.search.useQuery({
    limit: 6,
    offset: 0,
  });

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (searchMake) params.append("make", searchMake);
    if (searchModel) params.append("model", searchModel);
    if (searchMaxPrice) params.append("maxPrice", searchMaxPrice.toString());
    navigate(`/browse?${params.toString()}`);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border">
        <div className="container flex items-center justify-between py-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary" />
            <h1 className="text-2xl font-bold">CarMarket</h1>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Button variant="ghost" onClick={() => navigate("/dashboard")}>
                  Dashboard
                </Button>
                <Button variant="ghost" onClick={() => navigate("/my-listings")}>
                  My Listings
                </Button>
              </>
            ) : (
              <Button asChild>
                <a href={getLoginUrl()}>Sign In</a>
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="border-b border-border">
        <div className="container py-20">
          <div className="grid grid-cols-2 gap-16 items-center">
            {/* Left: Content */}
            <div>
              <h1 className="mb-6">
                Find Your Perfect Car
              </h1>
              <p className="text-lg text-foreground/70 mb-8">
                Browse thousands of quality vehicles from trusted sellers. Buy or sell with confidence on our secure marketplace.
              </p>
              <div className="flex gap-4">
                <Button size="lg" onClick={() => navigate("/browse")}>
                  Browse Cars
                </Button>
                {isAuthenticated && (
                  <Button size="lg" variant="outline" onClick={() => navigate("/create-listing")}>
                    <Plus className="w-4 h-4 mr-2" />
                    Sell a Car
                  </Button>
                )}
              </div>
            </div>

            {/* Right: Red accent square */}
            <div className="flex justify-end">
              <div className="w-full aspect-square bg-primary" />
            </div>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="border-b border-border">
        <div className="container py-16">
          <h2 className="mb-8">Search Cars</h2>
          <div className="grid grid-cols-4 gap-4">
            <Input
              placeholder="Make (e.g., Toyota)"
              value={searchMake}
              onChange={(e) => setSearchMake(e.target.value)}
            />
            <Input
              placeholder="Model (e.g., Camry)"
              value={searchModel}
              onChange={(e) => setSearchModel(e.target.value)}
            />
            <Input
              type="number"
              placeholder="Max Price"
              value={searchMaxPrice || ""}
              onChange={(e) => setSearchMaxPrice(e.target.value ? parseInt(e.target.value) : undefined)}
            />
            <Button onClick={handleSearch} className="w-full">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Listings */}
      <section className="border-b border-border">
        <div className="container py-16">
          <div className="flex items-center justify-between mb-8">
            <h2>Featured Listings</h2>
            <Button variant="ghost" onClick={() => navigate("/browse")}>
              View All <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-8">
              {featuredListings?.listings?.map((car) => (
                <div
                  key={car.id}
                  className="border border-border cursor-pointer hover:border-primary transition-colors"
                  onClick={() => navigate(`/car/${car.id}`)}
                >
                  <div className="aspect-video bg-secondary" />
                  <div className="p-6">
                    <h3 className="font-bold mb-2">
                      {car.year} {car.make} {car.model}
                    </h3>
                    <p className="text-sm text-foreground/60 mb-4">
                      {car.mileage.toLocaleString()} miles • {car.condition}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-primary">
                        ${car.price.toLocaleString()}
                      </span>
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="border-b border-border">
        <div className="container py-20">
          <div className="grid grid-cols-2 gap-16 items-center">
            {/* Left: Red accent */}
            <div className="flex justify-start">
              <div className="w-full aspect-square bg-primary" />
            </div>

            {/* Right: Content */}
            <div>
              <h2 className="mb-6">Ready to Sell?</h2>
              <p className="text-lg text-foreground/70 mb-8">
                List your car in minutes. Our AI-powered description generator helps you create compelling listings that attract buyers.
              </p>
              {isAuthenticated ? (
                <Button size="lg" onClick={() => navigate("/create-listing")}>
                  Create Listing
                </Button>
              ) : (
                <Button size="lg" asChild>
                  <a href={getLoginUrl()}>Get Started</a>
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="container py-12">
          <div className="grid grid-cols-4 gap-8 mb-12">
            <div>
              <h4 className="font-bold mb-4">Browse</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="/browse" className="hover:text-foreground">All Cars</a></li>
                <li><a href="/browse" className="hover:text-foreground">New Listings</a></li>
                <li><a href="/browse" className="hover:text-foreground">Best Deals</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Sell</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="#" className="hover:text-foreground">How It Works</a></li>
                <li><a href="#" className="hover:text-foreground">Pricing</a></li>
                <li><a href="#" className="hover:text-foreground">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="#" className="hover:text-foreground">About</a></li>
                <li><a href="#" className="hover:text-foreground">Contact</a></li>
                <li><a href="#" className="hover:text-foreground">Blog</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="#" className="hover:text-foreground">Privacy</a></li>
                <li><a href="#" className="hover:text-foreground">Terms</a></li>
                <li><a href="#" className="hover:text-foreground">Security</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8">
            <p className="text-sm text-foreground/60">
              © 2026 CarMarket. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
