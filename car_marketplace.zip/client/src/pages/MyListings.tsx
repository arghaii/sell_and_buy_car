import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2, ChevronLeft, Plus, Trash2, Edit2 } from "lucide-react";
import { toast } from "sonner";

export default function MyListings() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const { data: listings, isLoading, refetch } = trpc.cars.getMyListings.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const deleteCar = trpc.cars.delete.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-foreground/60 mb-4">Please sign in to view your listings</p>
          <Button onClick={() => navigate("/")}>Go Home</Button>
        </div>
      </div>
    );
  }

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this listing?")) return;

    setDeletingId(id);
    try {
      await deleteCar.mutateAsync(id);
      toast.success("Listing deleted");
      refetch();
    } catch (error) {
      toast.error("Failed to delete listing");
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="container py-6">
          <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="mb-4">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex items-center justify-between">
            <h1>My Listings</h1>
            <Button onClick={() => navigate("/create-listing")}>
              <Plus className="w-4 h-4 mr-2" />
              New Listing
            </Button>
          </div>
        </div>
      </div>

      <div className="container py-12">
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : !listings || listings.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-foreground/60 mb-4">You haven't created any listings yet</p>
            <Button onClick={() => navigate("/create-listing")}>
              Create Your First Listing
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {listings.map((car) => (
              <div key={car.id} className="border border-border p-6 flex items-center justify-between hover:border-primary transition-colors">
                <div className="flex-1">
                  <h3 className="font-bold mb-2">
                    {car.year} {car.make} {car.model}
                  </h3>
                  <div className="flex gap-6 text-sm text-foreground/60">
                    <span>${car.price.toLocaleString()}</span>
                    <span>{car.mileage.toLocaleString()} miles</span>
                    <span className="capitalize">{car.condition}</span>
                    <span>{car.isActive ? "Active" : "Inactive"}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate(`/car/${car.id}`)}
                  >
                    View
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate(`/edit-listing/${car.id}`)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(car.id)}
                    disabled={deletingId === car.id}
                  >
                    {deletingId === car.id ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
