import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2, ChevronLeft, Sparkles } from "lucide-react";
import { toast } from "sonner";

export default function CreateListing() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);

  const [formData, setFormData] = useState({
    make: "",
    model: "",
    year: new Date().getFullYear(),
    price: "",
    mileage: "",
    condition: "good" as const,
    description: "",
    color: "",
    transmission: "",
    fuelType: "",
    bodyType: "",
  });

  const createCar = trpc.cars.create.useMutation();
  const generateDescription = trpc.cars.generateDescription.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-foreground/60 mb-4">Please sign in to create a listing</p>
          <Button onClick={() => navigate("/")}>Go Home</Button>
        </div>
      </div>
    );
  }

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleGenerateDescription = async () => {
    if (!formData.make || !formData.model || !formData.year || !formData.mileage) {
      toast.error("Please fill in make, model, year, and mileage first");
      return;
    }

    setIsGeneratingDescription(true);
    try {
      const result = await generateDescription.mutateAsync({
        make: formData.make,
        model: formData.model,
        year: formData.year,
        mileage: parseInt(formData.mileage),
        condition: formData.condition,
        features: "",
      });
      handleInputChange("description", result.description);
      toast.success("Description generated!");
    } catch (error) {
      toast.error("Failed to generate description");
    } finally {
      setIsGeneratingDescription(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await createCar.mutateAsync({
        make: formData.make,
        model: formData.model,
        year: formData.year,
        price: parseFloat(formData.price),
        mileage: parseInt(formData.mileage),
        condition: formData.condition,
        description: formData.description,
        color: formData.color,
        transmission: formData.transmission,
        fuelType: formData.fuelType,
        bodyType: formData.bodyType,
      });
      toast.success("Listing created successfully!");
      navigate("/my-listings");
    } catch (error) {
      toast.error("Failed to create listing");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="container py-6">
          <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="mb-4">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <h1>Create New Listing</h1>
        </div>
      </div>

      <div className="container py-12">
        <div className="max-w-2xl">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Basic Info */}
            <div className="border-b border-border pb-8">
              <h2 className="mb-6">Vehicle Information</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">Make</label>
                  <Input
                    placeholder="e.g., Toyota"
                    value={formData.make}
                    onChange={(e) => handleInputChange("make", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Model</label>
                  <Input
                    placeholder="e.g., Camry"
                    value={formData.model}
                    onChange={(e) => handleInputChange("model", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Year</label>
                  <Input
                    type="number"
                    value={formData.year}
                    onChange={(e) => handleInputChange("year", parseInt(e.target.value))}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Mileage</label>
                  <Input
                    type="number"
                    placeholder="e.g., 45000"
                    value={formData.mileage}
                    onChange={(e) => handleInputChange("mileage", e.target.value)}
                    required
                  />
                </div>
              </div>
            </div>

            {/* Pricing & Condition */}
            <div className="border-b border-border pb-8">
              <h2 className="mb-6">Pricing & Condition</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">Price</label>
                  <Input
                    type="number"
                    placeholder="e.g., 25000"
                    value={formData.price}
                    onChange={(e) => handleInputChange("price", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Condition</label>
                  <Select value={formData.condition} onValueChange={(val) => handleInputChange("condition", val)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excellent">Excellent</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="fair">Fair</SelectItem>
                      <SelectItem value="poor">Poor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Details */}
            <div className="border-b border-border pb-8">
              <h2 className="mb-6">Vehicle Details</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">Color</label>
                  <Input
                    placeholder="e.g., Silver"
                    value={formData.color}
                    onChange={(e) => handleInputChange("color", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Transmission</label>
                  <Input
                    placeholder="e.g., Automatic"
                    value={formData.transmission}
                    onChange={(e) => handleInputChange("transmission", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Fuel Type</label>
                  <Input
                    placeholder="e.g., Gasoline"
                    value={formData.fuelType}
                    onChange={(e) => handleInputChange("fuelType", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Body Type</label>
                  <Input
                    placeholder="e.g., Sedan"
                    value={formData.bodyType}
                    onChange={(e) => handleInputChange("bodyType", e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="border-b border-border pb-8">
              <div className="flex items-center justify-between mb-6">
                <h2>Description</h2>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleGenerateDescription}
                  disabled={isGeneratingDescription}
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  {isGeneratingDescription ? "Generating..." : "AI Generate"}
                </Button>
              </div>
              <Textarea
                placeholder="Describe your vehicle's condition, features, and any notable history..."
                value={formData.description}
                onChange={(e) => handleInputChange("description", e.target.value)}
                className="min-h-32"
              />
            </div>

            {/* Submit */}
            <div className="flex gap-4">
              <Button
                type="submit"
                disabled={isSubmitting}
                className="flex-1"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create Listing"
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/")}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
