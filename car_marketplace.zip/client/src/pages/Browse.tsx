import { useLocation } from "wouter";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Loader2, ChevronLeft } from "lucide-react";

export default function Browse() {
  const [, navigate] = useLocation();
  const [make, setMake] = useState("");
  const [model, setModel] = useState("");
  const [minPrice, setMinPrice] = useState<number | undefined>();
  const [maxPrice, setMaxPrice] = useState<number | undefined>();
  const [minYear, setMinYear] = useState<number | undefined>();
  const [maxYear, setMaxYear] = useState<number | undefined>();
  const [condition, setCondition] = useState<'excellent' | 'good' | 'fair' | 'poor' | undefined>();
  const [offset, setOffset] = useState(0);

  const { data: searchResults, isLoading } = trpc.cars.search.useQuery({
    make: make || undefined,
    model: model || undefined,
    minPrice,
    maxPrice,
    minYear,
    maxYear,
    condition,
    limit: 12,
    offset,
  });

  const listings = searchResults?.listings || [];
  const hasMore = listings.length === 12;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="container py-6">
          <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="mb-4">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <h1>Browse Cars</h1>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid grid-cols-4 gap-8">
          {/* Filters */}
          <div className="border-r border-border pr-8">
            <h3 className="font-bold mb-6">Filters</h3>

            <div className="space-y-6">
              {/* Make */}
              <div>
                <label className="block text-sm font-semibold mb-2">Make</label>
                <Input
                  placeholder="e.g., Toyota"
                  value={make}
                  onChange={(e) => {
                    setMake(e.target.value);
                    setOffset(0);
                  }}
                />
              </div>

              {/* Model */}
              <div>
                <label className="block text-sm font-semibold mb-2">Model</label>
                <Input
                  placeholder="e.g., Camry"
                  value={model}
                  onChange={(e) => {
                    setModel(e.target.value);
                    setOffset(0);
                  }}
                />
              </div>

              {/* Price Range */}
              <div>
                <label className="block text-sm font-semibold mb-2">Price Range</label>
                <div className="space-y-2">
                  <Input
                    type="number"
                    placeholder="Min"
                    value={minPrice || ""}
                    onChange={(e) => {
                      setMinPrice(e.target.value ? parseInt(e.target.value) : undefined);
                      setOffset(0);
                    }}
                  />
                  <Input
                    type="number"
                    placeholder="Max"
                    value={maxPrice || ""}
                    onChange={(e) => {
                      setMaxPrice(e.target.value ? parseInt(e.target.value) : undefined);
                      setOffset(0);
                    }}
                  />
                </div>
              </div>

              {/* Year Range */}
              <div>
                <label className="block text-sm font-semibold mb-2">Year Range</label>
                <div className="space-y-2">
                  <Input
                    type="number"
                    placeholder="Min Year"
                    value={minYear || ""}
                    onChange={(e) => {
                      setMinYear(e.target.value ? parseInt(e.target.value) : undefined);
                      setOffset(0);
                    }}
                  />
                  <Input
                    type="number"
                    placeholder="Max Year"
                    value={maxYear || ""}
                    onChange={(e) => {
                      setMaxYear(e.target.value ? parseInt(e.target.value) : undefined);
                      setOffset(0);
                    }}
                  />
                </div>
              </div>

              {/* Condition */}
              <div>
                <label className="block text-sm font-semibold mb-2">Condition</label>
                <Select value={condition || ""} onValueChange={(val) => {
                  setCondition(val as any);
                  setOffset(0);
                }}>
                  <SelectTrigger>
                    <SelectValue placeholder="All conditions" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All conditions</SelectItem>
                    <SelectItem value="excellent">Excellent</SelectItem>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="fair">Fair</SelectItem>
                    <SelectItem value="poor">Poor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Reset */}
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setMake("");
                  setModel("");
                  setMinPrice(undefined);
                  setMaxPrice(undefined);
                  setMinYear(undefined);
                  setMaxYear(undefined);
                  setCondition(undefined);
                  setOffset(0);
                }}
              >
                Reset Filters
              </Button>
            </div>
          </div>

          {/* Listings */}
          <div className="col-span-3">
            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : listings.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-foreground/60">No cars found matching your criteria.</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-3 gap-8 mb-8">
                  {listings.map((car) => (
                    <div
                      key={car.id}
                      className="border border-border cursor-pointer hover:border-primary transition-colors"
                      onClick={() => navigate(`/car/${car.id}`)}
                    >
                      <div className="aspect-video bg-secondary" />
                      <div className="p-6">
                        <h3 className="font-bold mb-2">
                          {car.year} {car.make} {car.model}
                        </h3>
                        <p className="text-sm text-foreground/60 mb-2">
                          {car.mileage.toLocaleString()} miles
                        </p>
                        <p className="text-xs text-foreground/50 mb-4">
                          {car.condition} • {car.transmission || "Auto"}
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold text-primary">
                            ${car.price.toLocaleString()}
                          </span>
                          <Button variant="outline" size="sm">
                            View
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pagination */}
                <div className="flex justify-center gap-4">
                  <Button
                    variant="outline"
                    disabled={offset === 0}
                    onClick={() => setOffset(Math.max(0, offset - 12))}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    disabled={!hasMore}
                    onClick={() => setOffset(offset + 12)}
                  >
                    Next
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
