import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Car listings
  cars: router({
    // Get all active listings with search and filters
    search: publicProcedure
      .input(z.object({
        make: z.string().optional(),
        model: z.string().optional(),
        minPrice: z.number().optional(),
        maxPrice: z.number().optional(),
        minYear: z.number().optional(),
        maxYear: z.number().optional(),
        minMileage: z.number().optional(),
        maxMileage: z.number().optional(),
        condition: z.enum(['excellent', 'good', 'fair', 'poor']).optional(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      }))
      .query(({ input }) => db.searchCarListings(input)),

    // Get single car listing by ID
    getById: publicProcedure
      .input(z.number())
      .query(({ input }) => db.getCarListingById(input)),

    // Create new car listing (sellers only)
    create: protectedProcedure
      .input(z.object({
        make: z.string(),
        model: z.string(),
        year: z.number(),
        price: z.number(),
        mileage: z.number(),
        condition: z.enum(['excellent', 'good', 'fair', 'poor']),
        description: z.string().optional(),
        color: z.string().optional(),
        transmission: z.string().optional(),
        fuelType: z.string().optional(),
        bodyType: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createCarListing({
        sellerId: ctx.user!.id,
        ...input,
        price: input.price as any,
      })),

    // Update car listing
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        make: z.string().optional(),
        model: z.string().optional(),
        year: z.number().optional(),
        price: z.number().optional(),
        mileage: z.number().optional(),
        condition: z.enum(['excellent', 'good', 'fair', 'poor']).optional(),
        description: z.string().optional(),
        color: z.string().optional(),
        transmission: z.string().optional(),
        fuelType: z.string().optional(),
        bodyType: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, price, ...updateData } = input;
        const listing = await db.getCarListingById(id);
        if (!listing || listing.sellerId !== ctx.user!.id) {
          throw new Error("Unauthorized");
        }
        const updatePayload: any = updateData;
        if (price !== undefined) {
          updatePayload.price = price as any;
        }
        return db.updateCarListing(id, updatePayload);
      }),

    // Delete car listing
    delete: protectedProcedure
      .input(z.number())
      .mutation(async ({ ctx, input }) => {
        const listing = await db.getCarListingById(input);
        if (!listing || listing.sellerId !== ctx.user!.id) {
          throw new Error("Unauthorized");
        }
        return db.deleteCarListing(input);
      }),

    // Get seller's listings
    getMyListings: protectedProcedure
      .query(({ ctx }) => db.getSellerListings(ctx.user!.id)),

    // Generate description with LLM
    generateDescription: protectedProcedure
      .input(z.object({
        make: z.string(),
        model: z.string(),
        year: z.number(),
        mileage: z.number(),
        condition: z.enum(['excellent', 'good', 'fair', 'poor']),
        features: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Generate a compelling car listing description for a ${input.year} ${input.make} ${input.model} with ${input.mileage} miles in ${input.condition} condition${input.features ? `. Key features: ${input.features}` : ''}. Keep it concise (2-3 sentences) and highlight the key selling points.`;
        
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "You are a professional car salesman writing compelling vehicle descriptions." },
            { role: "user", content: prompt },
          ],
        });
        
        return { description: response.choices[0]?.message.content || "" };
      }),
  }),

  // Car images
  images: router({
    // Upload car image to S3
    upload: protectedProcedure
      .input(z.object({
        carId: z.number(),
        imageData: z.string(), // base64 encoded
        isPrimary: z.boolean().default(false),
      }))
      .mutation(async ({ ctx, input }) => {
        // Verify ownership
        const listing = await db.getCarListingById(input.carId);
        if (!listing || listing.sellerId !== ctx.user!.id) {
          throw new Error("Unauthorized");
        }

        const buffer = Buffer.from(input.imageData, 'base64');
        const fileName = `car-${input.carId}-${Date.now()}.jpg`;
        const { url } = await storagePut(`cars/${input.carId}/${fileName}`, buffer, 'image/jpeg');
        
        await db.addCarImage(input.carId, url, `cars/${input.carId}/${fileName}`, input.isPrimary);
        return { url };
      }),

    // Get car images
    getByCarId: publicProcedure
      .input(z.number())
      .query(({ input }) => db.getCarImages(input)),
  }),

  // Buyer inquiries
  inquiries: router({
    // Create inquiry
    create: protectedProcedure
      .input(z.object({
        carId: z.number(),
        message: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const inquiry = await db.createBuyerInquiry(input.carId, ctx.user!.id, input.message);
        const listing = await db.getCarListingById(input.carId);
        
        // Notify seller
        if (listing) {
          await db.createNotification(
            listing.sellerId,
            'buyer_inquiry',
            `New inquiry on your ${listing.year} ${listing.make} ${listing.model}`,
            input.message,
            input.carId
          );
        }
        
        return inquiry;
      }),

    // Get inquiries for a car
    getByCarId: protectedProcedure
      .input(z.number())
      .query(async ({ ctx, input }) => {
        const listing = await db.getCarListingById(input);
        if (!listing || listing.sellerId !== ctx.user!.id) {
          throw new Error("Unauthorized");
        }
        return db.getBuyerInquiries(input);
      }),

    // Update inquiry status
    updateStatus: protectedProcedure
      .input(z.object({
        inquiryId: z.number(),
        status: z.enum(['pending', 'contacted', 'interested', 'rejected']),
      }))
      .mutation(({ input }) => db.updateInquiryStatus(input.inquiryId, input.status)),
  }),

  // Notifications
  notifications: router({
    // Get user notifications
    getAll: protectedProcedure
      .query(({ ctx }) => db.getUserNotifications(ctx.user!.id)),

    // Mark as read
    markAsRead: protectedProcedure
      .input(z.number())
      .mutation(({ input }) => db.markNotificationAsRead(input)),
  }),
});

export type AppRouter = typeof appRouter;
