import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock user context
function createMockContext(userId: number = 1): TrpcContext {
  return {
    user: {
      id: userId,
      openId: `test-user-${userId}`,
      email: `user${userId}@example.com`,
      name: `Test User ${userId}`,
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as any,
    res: {} as any,
  };
}

describe("Car Marketplace API", () => {
  describe("cars.search", () => {
    it("should search for cars with filters", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.cars.search({
        limit: 10,
        offset: 0,
      });

      expect(result).toBeDefined();
      expect(result.listings).toBeDefined();
      expect(Array.isArray(result.listings)).toBe(true);
      expect(result.total).toBeGreaterThanOrEqual(0);
    });

    it("should handle price filters", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.cars.search({
        minPrice: 10000,
        maxPrice: 50000,
        limit: 10,
        offset: 0,
      });

      expect(result).toBeDefined();
      expect(result.listings).toBeDefined();
    });

    it("should handle condition filter", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.cars.search({
        condition: "excellent",
        limit: 10,
        offset: 0,
      });

      expect(result).toBeDefined();
      expect(result.listings).toBeDefined();
    });
  });

  describe("cars.create", () => {
    it("should create a car listing", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.cars.create({
        make: "Toyota",
        model: "Camry",
        year: 2022,
        price: 25000,
        mileage: 15000,
        condition: "excellent",
        description: "Well-maintained vehicle",
        color: "Silver",
        transmission: "Automatic",
        fuelType: "Gasoline",
        bodyType: "Sedan",
      });

      expect(result).toBeDefined();
    });

    it("should require authentication for creating listings", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: {} as any,
      });

      try {
        await caller.cars.create({
          make: "Toyota",
          model: "Camry",
          year: 2022,
          price: 25000,
          mileage: 15000,
          condition: "excellent",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("cars.getMyListings", () => {
    it("should get seller's listings", async () => {
      const ctx = createMockContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.cars.getMyListings();

      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
    });

    it("should require authentication", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: {} as any,
      });

      try {
        await caller.cars.getMyListings();
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("inquiries.create", () => {
    it("should create a buyer inquiry", async () => {
      const ctx = createMockContext(2);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.inquiries.create({
        carId: 1,
        message: "I'm interested in this car",
      });

      expect(result).toBeDefined();
    });

    it("should require authentication for inquiries", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: {} as any,
      });

      try {
        await caller.inquiries.create({
          carId: 1,
          message: "I'm interested",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("notifications.getAll", () => {
    it("should get user notifications", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.notifications.getAll();

      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
    });

    it("should require authentication", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: {} as any,
      });

      try {
        await caller.notifications.getAll();
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("auth.logout", () => {
    it("should logout user", async () => {
      const ctx = createMockContext();
      const clearCookieCalls: any[] = [];

      ctx.res.clearCookie = (name: string, options: any) => {
        clearCookieCalls.push({ name, options });
      };

      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.logout();

      expect(result.success).toBe(true);
      expect(clearCookieCalls.length).toBe(1);
      expect(clearCookieCalls[0].name).toBe("app_session_id");
    });
  });
});
