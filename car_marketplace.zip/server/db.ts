import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, InsertCarListing } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Car listing queries
export async function getCarListingById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const { carListings, carImages } = await import("../drizzle/schema");
  const result = await db.select().from(carListings).where(eq(carListings.id, id)).limit(1);
  if (result.length === 0) return undefined;
  
  const images = await db.select().from(carImages).where(eq(carImages.carId, id));
  return { ...result[0], images };
}

export async function getSellerListings(sellerId: number) {
  const db = await getDb();
  if (!db) return [];
  const { carListings } = await import("../drizzle/schema");
  return db.select().from(carListings).where(eq(carListings.sellerId, sellerId));
}

export async function searchCarListings(filters: {
  make?: string;
  model?: string;
  minPrice?: number;
  maxPrice?: number;
  minYear?: number;
  maxYear?: number;
  minMileage?: number;
  maxMileage?: number;
  condition?: 'excellent' | 'good' | 'fair' | 'poor';
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) return { listings: [], total: 0 };
  const { carListings } = await import("../drizzle/schema");
  const { and, gte, lte, like, eq } = await import("drizzle-orm");
  
  const conditions: any[] = [eq(carListings.isActive, true)];
  
  if (filters.make) conditions.push(like(carListings.make, `%${filters.make}%`));
  if (filters.model) conditions.push(like(carListings.model, `%${filters.model}%`));
  if (filters.minPrice !== undefined) conditions.push(gte(carListings.price, filters.minPrice as any));
  if (filters.maxPrice !== undefined) conditions.push(lte(carListings.price, filters.maxPrice as any));
  if (filters.minYear !== undefined) conditions.push(gte(carListings.year, filters.minYear));
  if (filters.maxYear !== undefined) conditions.push(lte(carListings.year, filters.maxYear));
  if (filters.minMileage !== undefined) conditions.push(gte(carListings.mileage, filters.minMileage));
  if (filters.maxMileage !== undefined) conditions.push(lte(carListings.mileage, filters.maxMileage));
  if (filters.condition) conditions.push(eq(carListings.condition, filters.condition));
  
  const query = db.select().from(carListings).where(and(...conditions));
  const listings = await query.limit(filters.limit || 20).offset(filters.offset || 0);
  
  return { listings, total: listings.length };
}

export async function createCarListing(data: InsertCarListing) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { carListings } = await import("../drizzle/schema");
  const result = await db.insert(carListings).values(data);
  return result;
}

export async function updateCarListing(id: number, data: Partial<InsertCarListing>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { carListings } = await import("../drizzle/schema");
  return db.update(carListings).set(data).where(eq(carListings.id, id));
}

export async function deleteCarListing(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { carListings } = await import("../drizzle/schema");
  return db.delete(carListings).where(eq(carListings.id, id));
}

// Image queries
export async function addCarImage(carId: number, imageUrl: string, imageKey: string, isPrimary = false) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { carImages } = await import("../drizzle/schema");
  return db.insert(carImages).values({ carId, imageUrl, imageKey, isPrimary });
}

export async function getCarImages(carId: number) {
  const db = await getDb();
  if (!db) return [];
  const { carImages } = await import("../drizzle/schema");
  return db.select().from(carImages).where(eq(carImages.carId, carId));
}

// Inquiry queries
export async function createBuyerInquiry(carId: number, buyerId: number, message?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { buyerInquiries } = await import("../drizzle/schema");
  return db.insert(buyerInquiries).values({ carId, buyerId, message });
}

export async function getBuyerInquiries(carId: number) {
  const db = await getDb();
  if (!db) return [];
  const { buyerInquiries } = await import("../drizzle/schema");
  return db.select().from(buyerInquiries).where(eq(buyerInquiries.carId, carId));
}

export async function updateInquiryStatus(inquiryId: number, status: 'pending' | 'contacted' | 'interested' | 'rejected') {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { buyerInquiries } = await import("../drizzle/schema");
  return db.update(buyerInquiries).set({ status }).where(eq(buyerInquiries.id, inquiryId));
}

// Notification queries
export async function createNotification(userId: number, type: 'buyer_inquiry' | 'payment_received' | 'listing_update', title: string, content?: string, relatedCarId?: number, relatedInquiryId?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { notifications } = await import("../drizzle/schema");
  return db.insert(notifications).values({ userId, type, title, content, relatedCarId, relatedInquiryId });
}

export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const { notifications } = await import("../drizzle/schema");
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(notifications.createdAt);
}

export async function markNotificationAsRead(notificationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { notifications } = await import("../drizzle/schema");
  return db.update(notifications).set({ isRead: true }).where(eq(notifications.id, notificationId));
}

// Payment queries
export async function createPayment(inquiryId: number, buyerId: number, carId: number, amount: string | number, stripePaymentIntentId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { payments } = await import("../drizzle/schema");
  const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  return db.insert(payments).values({ inquiryId, buyerId, carId, amount: numAmount as any, stripePaymentIntentId });
}

export async function updatePaymentStatus(paymentId: number, status: 'pending' | 'succeeded' | 'failed' | 'cancelled') {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { payments } = await import("../drizzle/schema");
  return db.update(payments).set({ status }).where(eq(payments.id, paymentId));
}

export async function getPaymentByStripeId(stripePaymentIntentId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const { payments } = await import("../drizzle/schema");
  const result = await db.select().from(payments).where(eq(payments.stripePaymentIntentId, stripePaymentIntentId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}
